// Copyright 2026, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package com.ilha.relogios.ui.effect

enum class DeviceType {
    PHONE,
    PAD,
}
