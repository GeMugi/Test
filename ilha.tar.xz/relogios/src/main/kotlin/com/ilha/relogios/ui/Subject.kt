package com.ilha.relogios.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import com.ilha.relogios.Keys

/**
 * Acha o assunto do papel de parede (pessoa, bicho, objeto em destaque) com o recorte do ML Kit,
 * no próprio aparelho, e guarda a máscara no mesmo formato da área pintada (72×160).
 * "Plano de fundo" é o contrário dessa máscara.
 */
object Subject {
    private const val MW = 72
    private const val MH = 160
    private val REQ = Keys.PKG + ".WALL_REQ"
    private val RES = Keys.PKG + ".WALL_RES"
    @Volatile var busy = false

    fun detect(context: Context, store: Store, done: (String) -> Unit) {
        if (busy) return
        busy = true
        val app = context.applicationContext
        val main = Handler(Looper.getMainLooper())
        var finished = false
        lateinit var r: BroadcastReceiver
        fun finish(msg: String) {
            if (finished) return
            finished = true
            busy = false
            try { app.unregisterReceiver(r) } catch (_: Throwable) {}
            main.post { done(msg) }
        }
        r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d = i.getByteArrayExtra("jpg") ?: return
                val bmp = BitmapFactory.decodeByteArray(d, 0, d.size) ?: return finish(tr("Não consegui ler o papel de parede"))
                segment(bmp, store, ::finish)
            }
        }
        app.registerReceiver(r, IntentFilter(RES), Context.RECEIVER_EXPORTED)
        app.sendBroadcast(Intent(REQ).setPackage("com.android.systemui"))
        main.postDelayed({ finish(tr("A Interface do Sistema não respondeu (a extensão precisa estar ativa no LSPosed)")) }, 8000)
    }

    private fun segment(bmp: Bitmap, store: Store, finish: (String) -> Unit) {
        try {
            val opts = SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
            val seg = SubjectSegmentation.getClient(opts)
            seg.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { res ->
                    val buf = res.foregroundConfidenceMask
                    if (buf == null) { finish(tr("Nenhum assunto encontrado nesta imagem")); return@addOnSuccessListener }
                    val w = bmp.width
                    val h = bmp.height
                    buf.rewind()
                    val all = FloatArray(w * h)
                    buf.get(all)
                    // média por célula da grade
                    val out = ByteArray(MW * MH)
                    var any = 0
                    for (gy in 0 until MH) {
                        val y0 = gy * h / MH
                        val y1 = maxOf(y0 + 1, (gy + 1) * h / MH)
                        for (gx in 0 until MW) {
                            val x0 = gx * w / MW
                            val x1 = maxOf(x0 + 1, (gx + 1) * w / MW)
                            var s = 0f
                            var n = 0
                            for (y in y0 until minOf(y1, h)) for (x in x0 until minOf(x1, w)) { s += all[y * w + x]; n++ }
                            val v = if (n > 0) s / n else 0f
                            if (v > 0.3f) any++
                            out[gy * MW + gx] = (v.coerceIn(0f, 1f) * 255f).toInt().toByte()
                        }
                    }
                    seg.close()
                    if (any == 0) { finish(tr("Nenhum assunto encontrado nesta imagem")); return@addOnSuccessListener }
                    store.subjMask = Base64.encodeToString(out, Base64.NO_WRAP)
                    finish(tr("Assunto encontrado"))
                }
                .addOnFailureListener { e ->
                    seg.close()
                    finish(tr("Não consegui achar o assunto") + ": " + (e.message ?: e.toString()))
                }
        } catch (t: Throwable) {
            finish(tr("Não consegui achar o assunto") + ": " + (t.message ?: t.toString()))
        }
    }
}
