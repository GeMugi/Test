package com.ilha.relogios.ui

/** Tela em português; em aparelhos em outro idioma, inglês. */
object I18n {
    val en: Boolean = java.util.Locale.getDefault().language != "pt"

    fun t(s: String): String = if (en) M[s] ?: s else s

    private val M: Map<String, String> = mapOf(
        "Relógios do HyperOS 4" to "HyperOS 4 clocks",
        "Extensão ativa" to "Extension active",
        "Extensão não ativa" to "Extension not active",
        "Ative no LSPosed e reinicie a Interface do Sistema" to "Enable it in LSPosed and restart System UI",
        "Os ajustes valem na hora" to "Settings apply right away",
        "Sistema" to "System",
        "App da tela sempre ativa" to "Always-on display app",
        "Não instalado" to "Not installed",
        "com os relógios All in One" to "with All in One clocks",
        "sem os relógios All in One (precisa da versão do HyperOS 4)" to "without All in One clocks (needs the HyperOS 4 version)",
        "Hyper Eternity" to "Hyper Eternity",
        "Instalado" to "Installed",
        "Não instalado: o relógio fica no bloqueio, mas não acompanha a lista de notificações do Hyper Eternity nem aparece na cortina." to "Not installed: the clock works on the lock screen, but it does not follow Hyper Eternity's notification list or show in its curtain.",
        "Relógios" to "Clocks",
        "Modelos do HyperOS 4 no editor" to "HyperOS 4 styles in the editor",
        "O editor da tela de bloqueio passa a oferecer os relógios All in One. Feche e abra o editor depois de mudar." to "The lock screen editor offers the All in One clocks. Close and reopen the editor after changing this.",
        "No bloqueio" to "On the lock screen",
        "Quando o modelo escolhido é All in One, o bloqueio mostra o relógio do HyperOS 4." to "When an All in One style is chosen, the lock screen shows the HyperOS 4 clock.",
        "Acompanha as notificações" to "Follows notifications",
        "Encolhe e sobe quando as notificações chegam perto, como no HyperOS 4." to "Shrinks and moves up as notifications get close, like on HyperOS 4.",
        "Na cortina do Hyper Eternity" to "In the Hyper Eternity curtain",
        "O mesmo relógio na central estilo iOS, com o relógio do bloqueio." to "The same clock in the iOS-style curtain, with the lock screen clock.",
        "Vidro fosco" to "Frosted glass",
        "Números com vidro (escolhido no editor) ficam foscos, misturados com o fundo. Desligado: cor sólida." to "Digits with glass (chosen in the editor) look frosted, blended with the background. Off: solid color.",
        "Abrir o editor do bloqueio" to "Open the lock screen editor",
        "Não consegui abrir o editor" to "Could not open the editor",
        "Reiniciar a Interface do Sistema" to "Restart System UI",
        "Precisa de root" to "Needs root",
        "Sem root" to "No root",
        "Bibliotecas do sistema" to "System libraries",
        "Algumas funções do HyperOS 4 existem no HyperOS 3, mas vêm desligadas dentro das bibliotecas do sistema. O patcher lê as bibliotecas deste aparelho, confere se a função é exatamente a esperada e gera um módulo (Magisk, KernelSU ou APatch) com a cópia corrigida. Se o sistema for atualizado, o módulo se desliga sozinho." to "Some HyperOS 4 features exist on HyperOS 3 but come switched off inside system libraries. The patcher reads this device's libraries, checks that the function is exactly the expected one and builds a module (Magisk, KernelSU or APatch) with the fixed copy. If the system is updated, the module switches itself off.",
        "Ligada no sistema" to "On in the system",
        "Desligada no sistema" to "Off in the system",
        "Não compatível" to "Not compatible",
        "Biblioteca não encontrada" to "Library not found",
        "Módulo" to "Module",
        "Conferir com root" to "Check with root",
        "Gerar e instalar o módulo" to "Build and install the module",
        "Remover o módulo" to "Remove the module",
        "Reiniciar o aparelho" to "Reboot the device",
        "Reiniciar agora?" to "Reboot now?",
        "O módulo só vale depois de reiniciar." to "The module only takes effect after a reboot.",
        "Cancelar" to "Cancel",
        "Reiniciar" to "Reboot",
        "Escolha ao menos um patch compatível" to "Pick at least one compatible patch",
        "Gerando…" to "Building…",
        "Instalado. Reinicie o aparelho para valer." to "Installed. Reboot for it to take effect.",
        "Marcado para sair. Reinicie o aparelho." to "Marked for removal. Reboot the device.",
        "Instalado e ativo" to "Installed and active",
        "Instalado, vale ao reiniciar" to "Installed, takes effect after reboot",
        "Sai ao reiniciar" to "Will be removed on reboot",
        "Desligado" to "Disabled",
        "Sem root: o patcher precisa de root para instalar o módulo." to "No root: the patcher needs root to install the module.",
        "Falhou" to "Failed",
        "Proteção" to "Protection",
        "A Interface do Sistema reiniciou em sequência logo depois desta opção ser ligada, então ela foi desligada:" to "System UI restarted repeatedly right after this option was turned on, so it was turned off:",
        "Sobre" to "About",
        "Extensão do Hyper Eternity para HyperOS 3. O código dos relógios é o do próprio app da tela sempre ativa instalado no aparelho; nada da Xiaomi vem dentro deste app." to "Hyper Eternity extension for HyperOS 3. The clock code is the one from the always-on display app installed on the device; nothing from Xiaomi ships inside this app.",
        "Versão" to "Version",
        "Código-fonte e licença (AGPL v3.0)" to "Source code and license (AGPL v3.0)",
        "no módulo" to "in the module",
        "Fonte variável nativa" to "Native variable font",
        "Liga a chave typeface_redesign_readonly do motor de texto: o relógio do HyperOS 4 muda espessura e tamanho sem pesar (o HyperOS 3 vem com ela desligada)." to "Turns on the text engine's typeface_redesign_readonly switch: the HyperOS 4 clock changes weight and size smoothly (HyperOS 3 ships with it off).",
    )
}

fun tr(s: String): String = I18n.t(s)

@JvmName("trOrNull")
fun tr(s: String?): String? = s?.let { I18n.t(it) }
