package com.ilha.headsup.miuix

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ilha.headsup.miuix.effect.BgEffectBackground
import top.yukonga.miuix.kmp.basic.BasicComponent
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.SmallTopAppBar
import top.yukonga.miuix.kmp.basic.TabRow
import top.yukonga.miuix.kmp.basic.TabRowDefaults
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.blur.LayerBackdrop
import top.yukonga.miuix.kmp.blur.isRuntimeShaderSupported
import top.yukonga.miuix.kmp.blur.layerBackdrop
import top.yukonga.miuix.kmp.blur.rememberLayerBackdrop
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.GridView
import top.yukonga.miuix.kmp.icon.extended.Home
import top.yukonga.miuix.kmp.icon.extended.Info
import top.yukonga.miuix.kmp.icon.extended.Layers
import top.yukonga.miuix.kmp.icon.extended.Settings
import top.yukonga.miuix.kmp.overlay.OverlayDialog
import top.yukonga.miuix.kmp.preference.ArrowPreference
import top.yukonga.miuix.kmp.preference.OverlayDropdownPreference
import top.yukonga.miuix.kmp.preference.SliderPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.overScrollVertical
import top.yukonga.miuix.kmp.utils.scrollEndHaptic
import kotlin.math.roundToInt

private const val MODULE = "com.ilha.headsup"

/** Abas da barra de baixo, como no app de ajustes do módulo. */
private val Navs = listOf("Início", "Recursos", "Extensões", "Ajustes", "Sobre")

/** As mesmas categorias de Recursos do módulo. */
private val Categories = listOf(
    "Heads-up" to "Estilo, velocidade e conteúdo",
    "Notificações" to "Conversas, linhas de texto e visual dos cartões",
    "Gaveta e pilhas" to "Empilhamento e grupos em pilha",
    "Tela de bloqueio" to "Lista, relógio e rolagem",
    "Central estilo iOS" to "Cortina, relógio do bloqueio e fundo",
    "Barra de status" to "Pílulas do relógio e cores",
    "Música" to "Player da gaveta e brilho da capa",
    "Privacidade" to "Esconder apps e conversas",
)

private val ColorModes = listOf("Sistema", "Claro", "Escuro", "Cores do papel de parede")

private val PillColors = listOf(
    "Vermelho" to 0xFFFF3B30.toInt(),
    "Laranja" to 0xFFFF9500.toInt(),
    "Amarelo" to 0xFFFFCC00.toInt(),
    "Verde" to 0xFF34C759.toInt(),
    "Azul" to 0xFF0A84FF.toInt(),
    "Roxo" to 0xFFAF52DE.toInt(),
    "Rosa" to 0xFFFF2D55.toInt(),
    "Cinza" to 0xFF8E8E93.toInt(),
)

@Composable
fun IlhaScreen(store: Store) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val listState = rememberLazyListState()
    val barBehavior = MiuixScrollBehavior()
    val shaderOk = remember { isRuntimeShaderSupported() }
    val glassOn = shaderOk && store.glass.value
    val surface = MiuixTheme.colorScheme.surface
    val bgBackdrop = rememberLayerBackdrop {
        drawRect(surface)
        drawContent()
    }
    val cardBackdrop: LayerBackdrop? = if (glassOn) bgBackdrop else null

    var nav by remember { mutableIntStateOf(0) }
    var page by remember { mutableIntStateOf(-1) }
    var showReset by remember { mutableStateOf(false) }
    BackHandler(enabled = page >= 0 || nav != 0) {
        if (page >= 0) page = -1 else nav = 0
    }
    LaunchedEffect(nav, page) { listState.scrollToItem(0) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
                true
            } catch (t: Throwable) {
                false
            }
            toast(context, if (ok) "Ajustes exportados" else "Não consegui salvar o arquivo")
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (t: Throwable) {
                null
            }
            toast(context, if (text != null && store.importJson(text)) "Ajustes importados" else "Arquivo inválido")
        }
    }

    val title = if (nav == 1 && page >= 0) Categories[page].first else Navs[nav]

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = title,
                scrollBehavior = barBehavior,
                color = if (glassOn) Color.Transparent else surface,
            )
        },
        bottomBar = {
            NavigationBar(color = surface) {
                val icons = listOf(MiuixIcons.Home, MiuixIcons.GridView, MiuixIcons.Layers, MiuixIcons.Settings, MiuixIcons.Info)
                Navs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = nav == i,
                        onClick = {
                            nav = i
                            page = -1
                        },
                        icon = icons[i],
                        label = label,
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize()) {
            BgEffectBackground(
                dynamicBackground = store.animatedBg.value,
                effectBackground = store.animatedBg.value,
                isFullSize = true,
                modifier = Modifier.fillMaxSize(),
                bgModifier = if (glassOn) Modifier.layerBackdrop(bgBackdrop) else Modifier,
                alpha = { 0.55f },
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .scrollEndHaptic()
                        .overScrollVertical()
                        .nestedScroll(barBehavior.nestedScrollConnection),
                    contentPadding = PaddingValues(
                        top = innerPadding.calculateTopPadding(),
                        bottom = innerPadding.calculateBottomPadding() + 12.dp,
                    ),
                ) {
                    when (nav) {
                        0 -> homeTab(store, cardBackdrop, onFeatures = { nav = 1 })
                        1 -> if (page < 0) {
                            item(key = "cats") {
                                SmallTitle(text = "Recursos")
                                GlassCard(cardBackdrop) {
                                    Categories.forEachIndexed { i, c ->
                                        ArrowPreference(title = c.first, summary = c.second, onClick = { page = i })
                                    }
                                }
                            }
                        } else {
                            when (page) {
                                0 -> headsUpPage(store, cardBackdrop, context)
                                1 -> notificationsPage(store, cardBackdrop)
                                2 -> stacksPage(store, cardBackdrop)
                                3 -> lockPage(store, cardBackdrop)
                                4 -> curtainPage(store, cardBackdrop)
                                5 -> statusBarPage(store, cardBackdrop)
                                6 -> musicPage(store, cardBackdrop)
                                else -> privacyPage(cardBackdrop, context)
                            }
                        }
                        2 -> extensionsTab(store, cardBackdrop, context)
                        3 -> settingsTab(
                            store,
                            cardBackdrop,
                            shaderOk,
                            context,
                            onExport = { exporter.launch("hyper-eternity-ajustes.json") },
                            onImport = { importer.launch(arrayOf("application/json", "text/*")) },
                            onReset = { showReset = true },
                        )
                        else -> aboutTab(cardBackdrop, uriHandler)
                    }
                }
            }
        }

        OverlayDialog(
            show = showReset,
            title = "Restaurar tudo?",
            summary = "Todos os ajustes do Hyper Eternity voltam ao padrão.",
            onDismissRequest = { showReset = false },
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(text = "Cancelar", onClick = { showReset = false }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(20.dp))
                TextButton(
                    text = "Restaurar",
                    onClick = {
                        store.resetAll()
                        showReset = false
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColorsPrimary(),
                )
            }
        }
    }
}

// ------------------------------------------------------------------ peças

@Composable
private fun CardText(text: String) {
    Text(
        text = text,
        style = MiuixTheme.textStyles.body2,
        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    )
}

@Composable
private fun IntSlider(
    pref: IntPref,
    title: String,
    summary: String?,
    min: Int,
    max: Int,
    unit: String,
    step: Int = 5,
) {
    SliderPreference(
        value = pref.live.toFloat(),
        onValueChange = { v -> pref.live = ((v / step).roundToInt() * step).coerceIn(min, max) },
        onValueChangeFinished = { pref.save() },
        title = title,
        summary = summary,
        valueText = "${pref.live}$unit",
        valueRange = min.toFloat()..max.toFloat(),
    )
}

@Composable
private fun Toggle(pref: BoolPref, title: String, summary: String?) {
    SwitchPreference(
        title = title,
        summary = summary,
        checked = pref.value,
        onCheckedChange = { pref.value = it },
    )
}

@Composable
private fun ColorChoice(pref: IntPref, title: String) {
    val idx = PillColors.indexOfFirst { it.second == pref.value }.let { if (it < 0) 0 else it }
    OverlayDropdownPreference(
        title = title,
        items = PillColors.map { it.first },
        selectedIndex = idx,
        onSelectedIndexChange = { pref.value = PillColors[it].second },
    )
}

private fun LazyListScope.section(
    key: String,
    title: String?,
    backdrop: LayerBackdrop?,
    content: @Composable ColumnScope.() -> Unit,
) {
    item(key = key) {
        if (title != null) SmallTitle(text = title) else Spacer(Modifier.height(12.dp))
        GlassCard(backdrop, content = content)
    }
}

private fun toast(context: Context, text: String) {
    Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
}

private fun prop(name: String, def: String): String = try {
    val c = Class.forName("android.os.SystemProperties")
    val v = c.getMethod("get", String::class.java).invoke(null, name) as String
    if (v.isEmpty()) def else v
} catch (t: Throwable) {
    def
}

private fun openModule(context: Context, page: Int?) {
    try {
        val i = Intent().setClassName(context.packageName, "$MODULE.SettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (page != null) i.putExtra("page", page)
        context.startActivity(i)
    } catch (t: Throwable) {
        toast(context, "Não consegui abrir a tela clássica")
    }
}

// ------------------------------------------------------------------ Início

private fun LazyListScope.homeTab(store: Store, backdrop: LayerBackdrop?, onFeatures: () -> Unit) {
    item(key = "status") {
        val ok = store.connected.value
        val reached = store.reached.value
        val dark = isInDarkTheme()
        val bg = when {
            ok -> if (dark) Color(0xFF1B3324) else Color(0xFFE2F4E7)
            reached -> if (dark) Color(0xFF3A1F1F) else Color(0xFFFBE6E4)
            else -> if (dark) Color(0xFF3A1F1F) else Color(0xFFFBE6E4)
        }
        Box(
            modifier = Modifier
                .padding(horizontal = 12.dp)
                .padding(top = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(bg),
        ) {
            Column(Modifier.padding(start = 18.dp, top = 20.dp, end = 96.dp, bottom = 32.dp)) {
                Text(
                    text = when {
                        ok -> "Módulo ativo"
                        reached -> "Módulo não ativo"
                        else -> "Não consegui ler os ajustes"
                    },
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                    color = MiuixTheme.colorScheme.onSurface,
                )
                Text(
                    text = when {
                        ok -> "Versão ${store.moduleVersion.value} · os ajustes valem na hora"
                        reached -> "Versão ${store.moduleVersion.value} · ative no LSPosed e reinicie"
                        else -> "Abra o app de novo"
                    },
                    fontSize = 15.sp,
                    color = MiuixTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Image(
                painter = painterResource(R.drawable.ilha_logo),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 14.dp, bottom = 14.dp)
                    .size(72.dp)
                    .clip(RoundedCornerShape(18.dp)),
            )
        }
    }
    if (store.otherInstalled.value) {
        section("other", null, backdrop) {
            CardText("O Hyper Eternity normal também está instalado. Deixe só um dos dois ativo no LSPosed: se os dois estiverem, só o primeiro que carregar funciona.")
        }
    }
    section("dev", null, backdrop) {
        BasicComponent(title = "Modelo", summary = Build.MODEL)
        BasicComponent(title = "HyperOS", summary = prop("ro.mi.os.version.incremental", Build.VERSION.INCREMENTAL))
        BasicComponent(title = "Android", summary = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
    }
    section("on", null, backdrop) {
        val n = store.enabledCount.intValue
        ArrowPreference(
            title = "Recursos",
            summary = if (n == 0) "Nenhum ligado — tudo vem desligado" else if (n == 1) "1 recurso ligado" else "$n recursos ligados",
            onClick = onFeatures,
        )
    }
}

// ------------------------------------------------------------------ Recursos

private fun LazyListScope.headsUpPage(store: Store, backdrop: LayerBackdrop?, context: Context) {
    section("hu", "Heads-up", backdrop) {
        Toggle(store.huEnabled, "Efeito ativado", "A notificação aparece com a animação do estilo escolhido.")
        AnimatedVisibility(visible = store.huEnabled.value) {
            Column {
                val ios = store.huStyle.value == 1
                TabRow(
                    tabs = listOf("OriginOS", "iOS"),
                    selectedTabIndex = store.huStyle.value,
                    onTabSelected = { store.huStyle.value = it },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = TabRowDefaults.tabRowColors(
                        backgroundColor = MiuixTheme.colorScheme.onSurface.copy(alpha = 0.06f),
                        selectedBackgroundColor = MiuixTheme.colorScheme.surface,
                    ),
                )
                CardText(
                    if (ios) {
                        "Nasce do ícone do app na barra de status, cresce desfocando e, ao sair, volta para ele."
                    } else {
                        "Nasce da ilha e cresce até o lugar dela, com a mola do OriginOS."
                    },
                )
                val speed = if (ios) store.huIosSpeed else store.huSpeed
                val bounce = if (ios) store.huIosBounce else store.huBounce
                IntSlider(speed, "Velocidade", "Mais rápido encurta a animação; mais lento estica.", 50, 200, "%")
                IntSlider(bounce, "Bounce", "0% chega sem passar do ponto; 200% dá o dobro de pulo.", 0, 200, "%")
                ArrowPreference(
                    title = "Testar heads-up",
                    summary = "Teste ${if (ios) "iOS" else "OriginOS"}: velocidade ${speed.live}% · bounce ${bounce.live}%",
                    onClick = {
                        val r = Bridge.call(context, "test")
                        toast(
                            context,
                            if (r?.getBoolean("ok") == true) "O teste aparece em 1,5 s" else "Ligue as notificações do Hyper Eternity para testar",
                        )
                    },
                )
                ArrowPreference(
                    title = "Permitir flutuante",
                    summary = "Precisa de \"Notificações flutuantes\" ligado para o Hyper Eternity miuix.",
                    onClick = {
                        try {
                            context.startActivity(
                                Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        } catch (t: Throwable) {
                            toast(context, "Não consegui abrir os ajustes de notificação")
                        }
                    },
                )
            }
        }
    }
    section("hc", "Conteúdo da heads-up", backdrop) {
        Toggle(store.huNoActions, "Sem botões", "Recolhida, mostra só título e texto. Os botões aparecem ao expandir. Ligações e alarmes mantêm os botões.")
        Toggle(store.huSeparate, "Uma por notificação", "Mostra só a notificação nova, sem juntar com as anteriores do app.")
    }
}

private fun LazyListScope.notificationsPage(store: Store, backdrop: LayerBackdrop?) {
    section("tx", "Texto", backdrop) {
        Toggle(store.modalFull, "Mensagem inteira ao segurar", "Ao segurar uma notificação, o cartão mostra a mensagem completa, com rolagem.")
        Toggle(store.lines4, "Mais linhas de texto", "Os cartões da central mostram mais linhas da mensagem. Num grupo em pilha ficam com 3. A heads-up continua igual.")
        IntSlider(store.linesN, "Linhas de texto", "Quantas linhas os cartões da central mostram.", 2, 10, "", step = 1)
    }
    section("cc", "Notificações de conversa", backdrop) {
        Toggle(store.convTime, "Hora das conversas no canto", "A hora vai para o canto direito, como nos outros cartões. Até 1 hora mostra \"agora\" ou \"5 min\".")
        Toggle(store.convNoExpand, "Conversas sem a seta", "Esconde o botão de expandir. Puxe a notificação para expandir.")
        Toggle(store.convMiui, "Conversas no visual do HyperOS (teste)", "Monta as conversas como os outros cartões do HyperOS: foto, nome, última mensagem e hora no canto.")
        Toggle(store.convSplit, "Cada mensagem num cartão novo (teste)", "Como no iOS: cada mensagem nova vira um cartão. Precisa de \"Framework do sistema\" no escopo do LSPosed.")
        Toggle(store.convSender, "Grupos só com o nome de quem mandou (teste)", "Em grupos, o título mostra só quem mandou. Precisa de \"Framework do sistema\" no escopo.")
        CardText("Valem para as notificações novas ou atualizadas.")
    }
    section("vi", "Visual dos cartões", backdrop) {
        Toggle(store.bodyVib, "Texto das notificações com vibrance", "O conteúdo das notificações (menos o título) ganha o efeito vibrancy, como os tempos do player.")
        IntSlider(store.bodyVibN, "Intensidade do texto", "Quanto o texto clareia (escuro) ou escurece (claro) o vidro do cartão.", 0, 100, "%")
        Toggle(store.notifVib, "Hora das notificações como no iOS (teste)", "A hora das notificações ganha o mesmo efeito vibrancy, com a intensidade dos números do player.")
    }
}

private fun LazyListScope.stacksPage(store: Store, backdrop: LayerBackdrop?) {
    section("st", "Empilhamento na gaveta", backdrop) {
        Toggle(store.stEnabled, "Empilhar notificações", "As que passam do limite encolhem embaixo, como no HyperOS 4.")
        IntSlider(store.stOffset, "Limite acima do fim da tela", "Maior começa a pilha mais alto.", 0, 400, " dp", step = 2)
        Toggle(store.stGroups, "Grupos expandidos por cartão", "Cada notificação de um grupo aberto empilha separada.")
        Toggle(store.groupStack, "Grupos em pilha (teste)", "Notificações do mesmo app viram uma pilha de cartões. Toque para abrir; a seta empilha de novo.")
        IntSlider(store.gsSpeed, "Pilha: velocidade", "Mais alto é mais rápido.", 50, 200, "%")
        IntSlider(store.gsBounce, "Pilha: bounce", "0% sem pulo; 300% pula bem mais.", 0, 300, "%")
        IntSlider(store.gsDepth, "Pilha: profundidade", "Quanto os cartões de trás aparecem.", 4, 30, " dp", step = 1)
        IntSlider(store.gsShadow, "Pilha: sombra entre os cartões", "Sombra suave entre os cartões. 0% tira.", 0, 100, "%")
    }
}

private fun LazyListScope.lockPage(store: Store, backdrop: LayerBackdrop?) {
    section("kg", "Tela de bloqueio", backdrop) {
        Toggle(store.kgHmc, "Bloqueio com o HyperMusicCover", "Relógio, capa, player e ilha do bloqueio usam o HyperMusicCover (precisa da extensão, veja Extensões).")
        Toggle(store.kgKeep, "Manter notificações após desbloquear", "As notificações vistas continuam no bloqueio até serem apagadas.")
        Toggle(store.kgEnabled, "Empilhar no bloqueio", "Mostra todas as notificações e empilha as que passam do limite.")
        Toggle(store.kgScroll, "Rolar sem desbloquear", "Deslizar sobre as notificações rola a lista; fora delas, desbloqueia.")
        Toggle(store.kgClockFixed, "Relógio na posição inicial", "Com notificações, o relógio fica grande e no mesmo lugar.")
        Toggle(store.kgClock, "Relógio acompanha a rolagem", "Ao rolar, as notificações empurram o relógio para cima.")
        Toggle(store.kgBlur, "Desfoque no topo", "As notificações se desfocam ao passar sob a barra de status.")
        Toggle(store.kgIos, "Lista baixa (estilo iOS)", "A lista começa mais embaixo, perto do polegar.")
        IntSlider(store.kgStart, "Início da lista", "Onde o primeiro cartão começa com muitas notificações.", 25, 90, "%", step = 1)
        IntSlider(store.kgOffset, "Limite acima do fim da tela", "Deixe espaço para o cadeado e os atalhos de baixo.", 40, 500, " dp")
        Toggle(store.kgHide, "Puxar para empilhar (teste)", "Com a lista no topo, continue rolando: as notificações se empilham até sobrar o player.")
        CardText("Vale na próxima vez que a tela bloquear.")
    }
}

private fun LazyListScope.curtainPage(store: Store, backdrop: LayerBackdrop?) {
    section("ios", "Cortina", backdrop) {
        Toggle(store.shadeSheet, "Central em cortina (teste)", "A central desce do topo como uma cortina, com o fundo do bloqueio, relógio grande, lanterna e câmera. Desligado = central do HyperOS.")
        Toggle(store.sheetRound, "Cantos arredondados na cortina", "Arredonda a borda de baixo da cortina enquanto ela se move.")
        Toggle(store.sheetBlur, "Fundo desfocado", "Usa o desfoque do HyperOS (a tela de trás desfocada). Desligado = papel de parede do bloqueio.")
    }
    section("ck", "Relógio da cortina", backdrop) {
        Toggle(store.sheetLockClock, "Relógio do bloqueio na cortina (teste)", "Usa o mesmo modelo de relógio da tela de bloqueio (troca junto quando você muda o modelo). Alguns modelos sobem e encolhem ao rolar as notificações.")
        IntSlider(store.sheetClock, "Posição do relógio", "Quanto o relógio próprio da cortina (e a lista) descem a partir do topo. Não vale com o relógio do bloqueio.", 0, 240, " dp")
    }
}

private fun LazyListScope.statusBarPage(store: Store, backdrop: LayerBackdrop?) {
    section("pl", "Pílulas do relógio", backdrop) {
        Toggle(store.recPill, "Relógio vermelho ao gravar a tela", "Durante a gravação de tela, o relógio da barra de status ganha uma pílula vermelha, como no iOS.")
        Toggle(store.locPill, "Relógio azul com a localização em uso", "Quando algum app está usando a localização, o relógio ganha uma pílula azul.")
        Toggle(store.hotPill, "Relógio verde com o roteador ligado", "Com o roteador Wi-Fi (hotspot) ligado, o relógio ganha uma pílula verde.")
        Toggle(store.pillVib, "Vibrance na pílula do relógio", "Com uma pílula atrás, a hora vira um recorte e deixa ver o que está passando na tela.")
    }
    section("co", "Cores das pílulas", backdrop) {
        ColorChoice(store.recColor, "Cor da gravação")
        ColorChoice(store.locColor, "Cor da localização")
        ColorChoice(store.hotColor, "Cor do roteador")
        CardText("Para uma cor qualquer, use a tela de ajustes do próprio módulo.")
    }
}

private fun LazyListScope.musicPage(store: Store, backdrop: LayerBackdrop?) {
    section("pg", "Player da gaveta", backdrop) {
        Toggle(store.mediaPure, "Fundo igual às notificações", "O player usa o mesmo vidro das outras notificações, em vez do mais escuro.")
        Toggle(store.albumGlow, "Capa gira e brilha na troca", "Como no ColorOS 17: ao trocar a música, a capa gira e solta um brilho que se espalha pelo cartão.")
        IntSlider(store.glowPower, "Brilho: intensidade", "Quão forte o desfoque da capa aparece.", 10, 100, "%")
        IntSlider(store.glowSize, "Brilho: tamanho", "Até onde ele se espalha em volta da capa.", 40, 200, "%")
        IntSlider(store.glowDist, "Brilho: distância", "Quanto ele desce pelo cartão enquanto some.", 0, 250, "%")
        IntSlider(store.glowX, "Brilho: posição lateral", "Para a esquerda (negativo) ou direita, em % da capa.", -150, 150, "%")
        IntSlider(store.glowY, "Brilho: posição vertical", "Para cima (negativo) ou para baixo, em % da capa.", -100, 150, "%")
        IntSlider(store.glowTime, "Brilho: duração", "Mais alto é mais lento.", 50, 250, "%")
        Toggle(store.mediaEdge, "Título com as pontas desfocadas", "Nomes compridos rolam com as pontas desfocadas, em vez de cortadas.")
        Toggle(store.mediaCut, "Barra e tempos como no iOS (teste)", "A barra e os tempos ganham o efeito vibrancy do iOS, no tom do vidro.")
        IntSlider(store.mvText, "iOS: intensidade dos números", "Quanto os tempos clareiam (escuro) ou escurecem (claro) o vidro.", 0, 100, "%")
        IntSlider(store.mvTrack, "iOS: intensidade do trilho", "A parte da barra que ainda falta tocar.", 0, 100, "%")
        IntSlider(store.mvPlayed, "iOS: intensidade da parte tocada", "A parte da barra que já tocou.", 0, 100, "%")
    }
}

private fun LazyListScope.privacyPage(backdrop: LayerBackdrop?, context: Context) {
    section("pv", "Privacidade", backdrop) {
        CardText("Esconde o conteúdo das notificações de apps, conversas e contatos escolhidos. A escolha dos apps e contatos fica na tela do próprio módulo.")
        ArrowPreference(title = "Abrir Privacidade", summary = "Na tela clássica do módulo", onClick = { openModule(context, 7) })
    }
}

// ------------------------------------------------------------------ Extensões

private fun LazyListScope.extensionsTab(store: Store, backdrop: LayerBackdrop?, context: Context) {
    if (!store.musicInstalled.value) {
        section("ext", "HyperMusicCover-Enhanced", backdrop) {
            CardText("Capa do álbum e letras sincronizadas no bloqueio (HyperMusicCover-Enhanced, adaptado ao HyperOS 3). É um APK separado: instale a extensão \"HyperMusicCover-Enhanced\", ative no LSPosed e reinicie.")
        }
        return
    }
    section("mu", "Capa e letras no bloqueio", backdrop) {
        CardText("Player do bloqueio com capa em destaque e letras sincronizadas, do HyperMusicCover-Enhanced.")
        ArrowPreference(
            title = "Abrir ajustes da música",
            summary = "A tela da música é a original, em inglês.",
            onClick = {
                try {
                    context.startActivity(
                        Intent(Intent.ACTION_MAIN)
                            .setClassName("$MODULE.music", "com.os4.musiccover.MainActivity")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                } catch (t: Throwable) {
                    toast(context, "Não consegui abrir os ajustes da música")
                }
            },
        )
    }
    section("sy", "Sincronia das letras", backdrop) {
        IntSlider(store.lyricShift, "Adiantar a letra", "Quanto a letra anda à frente da música. Atrasada, aumente; adiantada, diminua.", -20, 30, " ds", step = 1)
        CardText("Versões de clipe podem ter cortes diferentes do álbum, e a letra pode não bater em algum trecho.")
    }
    section("il", "Ilha no bloqueio", backdrop) {
        CardText("A ilha do bloqueio é a do HyperMusicCover. Ligue em Abrir ajustes da música → \"Lock screen super island\". Para o vidro fosco, ligue \"Blur background\" na mesma tela.")
    }
}

// ------------------------------------------------------------------ Ajustes

private fun LazyListScope.settingsTab(
    store: Store,
    backdrop: LayerBackdrop?,
    shaderOk: Boolean,
    context: Context,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit,
) {
    section("ap", "Aparência", backdrop) {
        OverlayDropdownPreference(
            title = "Tema do app",
            items = ColorModes,
            selectedIndex = store.colorMode.value,
            onSelectedIndexChange = { store.colorMode.value = it },
        )
        SwitchPreference(
            title = "Fundo colorido animado",
            summary = "O degradê do HyperOS 3 atrás das telas.",
            checked = store.animatedBg.value,
            onCheckedChange = { store.animatedBg.value = it },
        )
        SwitchPreference(
            title = "Vidro fosco",
            summary = if (shaderOk) "Os cartões desfocam o que está atrás deles." else "Este aparelho não tem o recurso de desfoque que o miuix usa.",
            checked = store.glass.value,
            enabled = shaderOk,
            onCheckedChange = { store.glass.value = it },
        )
    }
    section("lo", "Registros", backdrop) {
        CardText("Os registros ficam no LSPosed (Registros → Módulos). Copie o resumo abaixo para mandar junto.")
        ArrowPreference(
            title = "Copiar resumo dos ajustes",
            onClick = {
                try {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("ajustes", "Hyper Eternity ${store.moduleVersion.value} · ${Build.DISPLAY}\n${store.exportJson()}"))
                    toast(context, "Resumo copiado")
                } catch (t: Throwable) {
                    toast(context, "Não consegui copiar")
                }
            },
        )
    }
    section("ie", "Importar e exportar", backdrop) {
        ArrowPreference(title = "Exportar", summary = "Salva todos os ajustes num arquivo.", onClick = onExport)
        ArrowPreference(title = "Importar", summary = "Carrega os ajustes de um arquivo.", onClick = onImport)
    }
    section("sys", "Sistema", backdrop) {
        ArrowPreference(
            title = "Reiniciar Interface do Sistema",
            summary = "Precisa de root.",
            onClick = { Bridge.call(context, "restart") },
        )
        ArrowPreference(title = "Restaurar tudo", summary = "Volta todos os ajustes ao padrão.", onClick = onReset)
        ArrowPreference(title = "Abrir os ajustes clássicos", summary = "A tela de ajustes do próprio módulo.", onClick = { openModule(context, null) })
    }
}

// ------------------------------------------------------------------ Sobre

private fun LazyListScope.aboutTab(backdrop: LayerBackdrop?, uriHandler: UriHandler) {
    item(key = "who") {
        Box(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
        ) {
            Image(
                painter = painterResource(R.drawable.eternity_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize(),
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Image(
                    painter = painterResource(R.drawable.eternity_avatar),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(128.dp)
                        .clip(CircleShape),
                )
                Text(
                    text = "Fabulous Lightning McQ",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 10.dp),
                )
                Text(text = "@Gmugi", fontSize = 15.sp, color = Color(0xDDFFFFFF))
            }
        }
    }
    section("tg", "Telegram", backdrop) {
        ArrowPreference(
            title = "Gmugi 愛",
            summary = "t.me/GmugiUwu",
            startAction = {
                Image(
                    painter = painterResource(R.drawable.eternity_channel),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(end = 14.dp)
                        .size(48.dp)
                        .clip(CircleShape),
                )
            },
            onClick = { uriHandler.openUri("https://t.me/GmugiUwu") },
        )
    }
    section("gh", "GitHub", backdrop) {
        ArrowPreference(
            title = "GeMugi/Hyper-Eternity",
            summary = "github.com/GeMugi/Hyper-Eternity",
            startAction = {
                Image(
                    painter = painterResource(R.drawable.ilha_logo),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(end = 14.dp)
                        .size(48.dp)
                        .clip(CircleShape),
                )
            },
            onClick = { uriHandler.openUri("https://github.com/GeMugi/Hyper-Eternity") },
        )
    }
    section("cr", "Créditos e licença", backdrop) {
        ArrowPreference(title = "HyperMusicCover", summary = "Autor original: zyl6932", onClick = { uriHandler.openUri("https://github.com/zyl6932/HyperMusicCover") })
        ArrowPreference(title = "HyperMusicCover-Enhanced", summary = "Versão melhorada: Lewewe", onClick = { uriHandler.openUri("https://github.com/Lewewe/HyperMusicCover-Enhanced") })
        ArrowPreference(title = "miuix", summary = "Componentes e desfoque desta tela (Apache 2.0)", onClick = { uriHandler.openUri("https://github.com/compose-miuix-ui/miuix") })
        CardText("O HyperMusicCover e o HyperMusicCover-Enhanced são AGPL v3.0, e o Hyper Eternity também.")
    }
}
